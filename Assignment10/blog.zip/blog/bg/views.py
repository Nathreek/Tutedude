from django.shortcuts import render , get_object_or_404

from bg.models import Post
def allposts(request):
    posts = Post.objects
    return render(request, 'bg/post.html', {'posts':posts})

def content(request, blog_id):
    con = get_object_or_404(Post, pk=blog_id)
    return render(request, 'bg/content.html', {'post': con})

