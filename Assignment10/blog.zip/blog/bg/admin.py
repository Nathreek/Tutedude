from django.contrib import admin

from bg.models import Post
admin.site.register(Post)

