from django.db import models

class Post(models.Model):
    title = models.CharField(max_length=200)
    date = models.DateTimeField()
    img = models.ImageField(upload_to='images/')
    body = models.TextField()

    def summary(self):
        return self.body[:100] 
    
    def pub_date(self):
        return self.date.strftime('%b %e, %y')
    
    def __str__(self):
        return self.title
